-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2021 at 07:33 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel8`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_image`, `created_at`, `updated_at`) VALUES
(2, 'Apple', 'image/brand/1689217532788812.jpg', '2021-01-16 08:54:15', '2021-01-18 04:49:36'),
(6, 'Nokia', 'image/brand/1689217485330085.jpg', '2021-01-18 03:10:01', '2021-01-18 04:48:50'),
(8, 'Mega', 'image/brand/1689478535734648.jpg', '2021-01-20 01:51:33', '2021-01-21 01:58:08'),
(38, 'Samsung S1', 'image/brand/1689683540070753.jpg', '2021-01-23 13:16:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `category_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Rent A Car', '2021-01-15 03:23:44', NULL, NULL),
(4, 1, 'Rent A Car', '2021-01-15 04:21:41', NULL, NULL),
(5, 1, 'Rent A Car', NULL, NULL, NULL),
(49, 1, 'Rent A Car', '2021-01-15 08:24:13', NULL, NULL),
(50, 1, 'Rent A Car', '2021-01-15 08:24:17', NULL, NULL),
(51, 1, 'Rent A Car', '2021-01-15 08:24:24', NULL, NULL),
(52, 1, 'Rent A Car', '2021-01-15 08:24:27', NULL, NULL),
(53, 1, 'Rent A Car', '2021-01-15 08:24:29', NULL, NULL),
(54, 1, 'Rent A Car', '2021-01-15 08:24:32', NULL, NULL),
(55, 1, 'Rent A Car', '2021-01-15 08:24:35', NULL, NULL),
(56, 1, 'Rent A Car', '2021-01-15 08:24:42', '2021-01-16 07:37:03', '2021-01-16 07:37:03'),
(62, 1, 'Rent A Car', '2021-01-15 08:25:01', NULL, NULL),
(99, 1, 'womens', '2021-01-16 04:57:39', NULL, NULL),
(100, 1, 'Mens', '2021-01-16 07:36:58', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `address`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(3, 'Street shair muhaamad wali, house # 1350\r\nmuhalla pepal bazar mailsi', 'anskhilji900@gmail.com', '0313-3341408', '2021-01-22 10:42:20', '2021-01-22 10:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact_forms`
--

CREATE TABLE IF NOT EXISTS `contact_forms` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_forms`
--

INSERT INTO `contact_forms` (`id`, `name`, `email`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Candice Dejesus', 'zuvirocov@mailinator.com', 'Aut est laborum vel', 'Quisquam ut necessit', '2021-01-22 12:02:34', '2021-01-22 12:02:34'),
(2, 'Andrew Christian', 'fepegi@mailinator.com', 'Obcaecati sunt opti', 'Anim eu incidunt ir', '2021-01-22 12:15:44', '2021-01-22 12:15:44'),
(3, 'Hayfa Sutton', 'tuho@mailinator.com', 'Dolorem natus nemo d', 'Aute commodo exercit', '2021-01-22 12:32:03', '2021-01-22 12:32:03'),
(4, 'Raymond Gallagher', 'jaqexuvub@mailinator.com', 'Id nisi ipsum quo co', 'Ut ab dolores aliqua', '2021-01-22 12:32:09', '2021-01-22 12:32:09'),
(5, 'Nathaniel Vazquez', 'munoxumuqu@mailinator.com', 'Sit velit asperiores', 'Numquam Nam amet es', '2021-01-22 12:32:14', '2021-01-22 12:32:14'),
(6, 'Denise Dillon', 'bepaca@mailinator.com', 'Culpa dolorem beata', 'Optio ullamco eius', '2021-01-22 12:32:20', '2021-01-22 12:32:20'),
(7, 'Emi Moody', 'rofexehaq@mailinator.com', 'Eum modi quis omnis', 'Minus dolore fugiat', '2021-01-22 12:32:29', '2021-01-22 12:32:29'),
(8, 'Keefe Owen', 'mequjyj@mailinator.com', 'Beatae vel atque sit', 'Dignissimos esse ea', '2021-01-22 12:32:36', '2021-01-22 12:32:36'),
(9, 'Kristen Juarez', 'gubovelid@mailinator.com', 'Ea error dolore simi', 'Ut odit ad ad modi n', '2021-01-22 12:32:49', '2021-01-22 12:32:49'),
(11, 'Jarrod Baldwin', 'bamadux@mailinator.com', 'Occaecat in dolor ei', 'Neque dolor dolor eu', '2021-01-22 12:33:36', '2021-01-22 12:33:36'),
(12, 'Nichole Pugh', 'tucecisusu@mailinator.com', 'Quam magna maiores n', 'Cupiditate sint ex a', '2021-01-22 12:33:42', '2021-01-22 12:33:42'),
(13, 'Casey Hays', 'sovuna@mailinator.com', 'Et unde deleniti cum', 'Ullam consectetur qu', '2021-01-22 12:33:56', '2021-01-22 12:33:56'),
(14, 'Brynne Bradley', 'sytyket@mailinator.com', 'Qui nobis eos qui su', 'Sint laborum Cupid', '2021-01-22 12:34:04', '2021-01-22 12:34:04'),
(15, 'Gemma Finch', 'fokelevame@mailinator.com', 'Blanditiis qui cillu', 'Quia culpa eum quia', '2021-01-22 12:34:18', '2021-01-22 12:34:18'),
(16, 'Dara Ross', 'rotazen@mailinator.com', 'Autem itaque quo qui', 'Distinctio Autem qu', '2021-01-22 12:36:54', '2021-01-22 12:36:54'),
(17, 'Jeanette Frost', 'jufycer@mailinator.com', 'Consequatur ad dolo', 'Qui vel voluptate se', '2021-01-22 12:37:03', '2021-01-22 12:37:03'),
(18, 'Anjolie Mays', 'vagyhycuz@mailinator.com', 'Consequatur Veritat', 'Sit asperiores repel', '2021-01-22 12:37:15', '2021-01-22 12:37:15');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `home_abouts`
--

CREATE TABLE IF NOT EXISTS `home_abouts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_dis` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_dis` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_abouts`
--

INSERT INTO `home_abouts` (`id`, `title`, `short_dis`, `long_dis`, `created_at`, `updated_at`) VALUES
(2, '1EUM IPSAM LABORUM DELENITI VELITENA', '1Voluptatem dignissimos provident quasi corporis voluptates sit assum perenda sruen jonee trave', '1Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum\r\n\r\nUllamco laboris nisi ut aliquip ex ea commodo consequa\r\nDuis aute irure dolor in reprehenderit in voluptate velit\r\nUllamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2021-01-21 05:30:36', '2021-01-21 11:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `home_services`
--

CREATE TABLE IF NOT EXISTS `home_services` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `des` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_services`
--

INSERT INTO `home_services` (`id`, `title`, `des`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'Web developer', 'Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'bx-file', '2021-01-21 13:01:47', '2021-01-21 13:01:47'),
(3, 'Laravel 7', 'Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'bx-tachometer', '2021-01-21 13:51:42', '2021-01-21 14:12:28'),
(4, 'service 3', 'Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'bx-layer', '2021-01-21 13:52:26', '2021-01-21 14:12:34'),
(5, 'Anskhan', 'Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'bx-slideshow', '2021-01-21 13:53:04', '2021-01-21 14:12:40'),
(6, 'finanzero.se', 'Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'bx-arch', '2021-01-21 13:53:22', '2021-01-21 14:12:46'),
(7, 'Laravel 9', 'Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'bxl-dribbble', '2021-01-21 14:08:35', '2021-01-23 13:54:17');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2021_01_08_115513_create_sessions_table', 1),
(7, '2021_01_09_065709_create_categories_table', 2),
(8, '2021_01_16_103136_create_brands_table', 3),
(9, '2021_01_18_093014_create_multi_pics_table', 4),
(10, '2021_01_20_100620_create_sliders_table', 5),
(11, '2021_01_21_074452_create_home_abouts_table', 6),
(12, '2021_01_21_173837_create_home_services_table', 7),
(13, '2021_01_22_121411_create_contacts_table', 8),
(14, '2021_01_22_155722_create_contact_forms_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `multi_pics`
--

CREATE TABLE IF NOT EXISTS `multi_pics` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `multi_pics`
--

INSERT INTO `multi_pics` (`id`, `image`, `created_at`, `updated_at`) VALUES
(17, 'image/multi/1689223660625570.jpg', '2021-01-18 06:27:00', NULL),
(18, 'image/multi/1689223661056629.jpg', '2021-01-18 06:27:00', NULL),
(19, 'image/multi/1689223662013314.jpg', '2021-01-18 06:27:01', NULL),
(20, 'image/multi/1689223947165947.jpg', '2021-01-18 06:31:33', NULL),
(21, 'image/multi/1689223947498876.jpg', '2021-01-18 06:31:33', NULL),
(22, 'image/multi/1689223948021192.jpg', '2021-01-18 06:31:34', NULL),
(23, 'image/multi/1689224231303344.jpg', '2021-01-18 06:36:04', NULL),
(24, 'image/multi/1689224644670543.jpg', '2021-01-18 06:42:38', NULL),
(25, 'image/multi/1689224645099702.jpg', '2021-01-18 06:42:38', NULL),
(26, 'image/multi/1689224856904719.jpg', '2021-01-18 06:46:00', NULL),
(27, 'image/multi/1689224857188131.jpg', '2021-01-18 06:46:01', NULL),
(28, 'image/multi/1689224857481313.jpg', '2021-01-18 06:46:01', NULL),
(29, 'image/multi/1689225038939947.jpg', '2021-01-18 06:48:54', NULL),
(30, 'image/multi/1689225039232590.jpg', '2021-01-18 06:48:54', NULL),
(31, 'image/multi/1689225039477066.jpg', '2021-01-18 06:48:55', NULL),
(32, 'image/multi/1689225201989366.jpg', '2021-01-18 06:51:29', NULL),
(33, 'image/multi/1689225527474031.jpg', '2021-01-18 06:56:40', NULL),
(34, 'image/multi/1689225793567677.jpg', '2021-01-18 07:00:54', NULL),
(35, 'image/multi/1689225793900888.jpg', '2021-01-18 07:00:54', NULL),
(36, 'image/multi/1689226384245122.jpg', '2021-01-18 07:10:17', NULL),
(37, 'image/multi/1689226572331207.jpg', '2021-01-18 07:13:16', NULL),
(38, 'image/multi/1689226572591224.jpg', '2021-01-18 07:13:17', NULL),
(39, 'image/multi/1689226572905070.jpg', '2021-01-18 07:13:17', NULL),
(40, 'image/multi/1689226573165763.jpg', '2021-01-18 07:13:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('5HIQqFnj7XCuRc0s3zjgKndeykY9dRRJzSdEvDhn', 34, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36', 'YTo3OntzOjM6InVybCI7YTowOnt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC91c2VyL3Byb2ZpbGUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjY6Il90b2tlbiI7czo0MDoibWVrTFpXRGg2bmtQZWY1ckR6SXFrT2FtYUFUdXhFZmc2ZnNZTkwwNiI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MzQ7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRCanZGZHBZeXlyZ05NSFNPNTV3c3Iua252Q2RGMHQ5MUFvcXpFR25CcWJiRUEuMHZnTUN3ZSI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMnkkMTAkQmp2RmRwWXl5cmdOTUhTTzU1d3NyLmtudkNkRjB0OTFBb3F6RUduQnFiYkVBLjB2Z01Dd2UiO30=', 1611417940),
('vVOo1FsebPqfDaOzZo2n16843VGmDjUXfLXWgWpE', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoicHBUM1pwVHJZMm5pVjR5Ym9uR3M5WUI2Z0tEUkt4VW96WG5qcFh2biI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkTW9FaklESTcxcC8ud3hkLjQyc2dvdUp0Ti9MTkwxQ1phdFluNE43V1kuSC9XWllrcnJKQ08iO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEwJE1vRWpJREk3MXAvLnd4ZC40MnNnb3VKdE4vTE5MMUNaYXRZbjRON1dZLkgvV1pZa3JySkNPIjt9', 1611553984);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE IF NOT EXISTS `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(9, 'Slider 2', 'Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Cras ultricies ligula sed magna dictum porta. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'image/slider/1689478906948148.jpg', '2021-01-21 02:04:02', NULL),
(11, 'Slider 2', 'Cras ultricies ligula sed magna dictum porta. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus.', 'image/slider/1689480442834507.jpg', '2021-01-21 02:28:26', NULL),
(12, 'Slider 3', 'Cras ultricies ligula sed magna dictum porta. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus.', 'image/slider/1689480485799640.jpg', '2021-01-21 02:29:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'Anskhan', 'anskhilji900@gmail.com', '2021-01-19 01:17:03', '$2y$10$MoEjIDI71p/.wxd.42sgouJtN/LNL1CZatYn4N7WY.H/WZYkrrJCO', NULL, NULL, 'KmZogJ4lhcM5G1U40zpujOZR4umjmA9qbX0yoLj8hOCJDiHruea6BHC3fwcY', NULL, NULL, '2021-01-08 07:17:11', '2021-01-23 11:34:37'),
(2, 'arman', 'asfand@gmail.com', '2021-01-19 05:38:36', '$2y$10$poJiYnYA4UNSvEmD8v/BHuKLuNxZZBE99toULCPtH4P9YqXmKh7mq', NULL, NULL, 'd21PD1iAP3vs7svM76bELf7khuoBBiDLjklBh3u2FMKWE1afMXXqGE5f3yw1', NULL, NULL, '2021-01-09 01:18:21', '2021-01-19 05:38:36'),
(33, 'Naeem', 'naeem@gmail.com', '2021-01-23 11:39:40', '$2y$10$NwuX/ejn9w4d7w976iWWbeZ.h4wtsaE8vw/5ck14lMuMkDxfB6rhG', NULL, NULL, NULL, NULL, 'image/profile/1689679773857342.jpg', '2021-01-23 11:38:53', '2021-01-23 12:16:43'),
(34, 'Asim Farid', 'khan@gmail.com', '2021-01-23 12:19:44', '$2y$10$BjvFdpYyyrgNMHSO55wsr.knvCdF0t91AoqzEGnBqbbEA.0vgMCwe', NULL, NULL, NULL, NULL, 'image/profile/1689694176825464.jpg', '2021-01-23 12:18:14', '2021-01-23 16:05:39');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
